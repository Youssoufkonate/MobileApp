package com.itec4550.animation;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.os.Bundle;
import android.widget.ImageView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ImageView imageView = findViewById(R.id.myImageView);

        // Create translation animations for up, down, left, and right
        ObjectAnimator moveUp = ObjectAnimator.ofFloat(imageView, "translationY", 600f, -600f);
        moveUp.setDuration(450);
        moveUp.setRepeatMode(ObjectAnimator.REVERSE);
        moveUp.setRepeatCount(ObjectAnimator.INFINITE);

        ObjectAnimator moveDown = ObjectAnimator.ofFloat(imageView, "translationY", -600f, 600f);
        moveDown.setDuration(500);
        moveDown.setRepeatMode(ObjectAnimator.REVERSE);
        moveDown.setRepeatCount(ObjectAnimator.INFINITE);

        ObjectAnimator moveLeft = ObjectAnimator.ofFloat(imageView, "translationX", 200f, -200f);
        moveLeft.setDuration(500);
        moveLeft.setRepeatMode(ObjectAnimator.REVERSE);
        moveLeft.setRepeatCount(ObjectAnimator.INFINITE);

        ObjectAnimator moveRight = ObjectAnimator.ofFloat(imageView, "translationX", -200f, 200f);
        moveRight.setDuration(500);
        moveRight.setRepeatMode(ObjectAnimator.REVERSE);
        moveRight.setRepeatCount(ObjectAnimator.INFINITE);

        // Combine animations
        AnimatorSet animatorSet = new AnimatorSet();
        animatorSet.playSequentially(moveLeft);
        animatorSet.playSequentially(moveUp);
        animatorSet.playSequentially(moveRight);
        animatorSet.playSequentially(moveLeft);
                animatorSet.start();
    }
}
